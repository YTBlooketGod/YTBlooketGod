# Blooket-Hacks-2.0 & Other Things

**SBS Students, DO NOT tell other people. Only @YTBlooketGod can (If told, this page maybe deleted).**

*If some hacks aren't working, go to "Discussions" above & comment under "Error Discussion".*

The View Each Hack click on the file above where it says Global, Crazy Kingdom, etc.
If some hacks aren't working, comment please.


All of the cheats are based on a game mode.

**All these bookmarklets are also at: https://schoolcheats.net/blooket**

Video Tutorial:
 https://streamable.com/qshq4z


Bookmarklet tutorial:
 https://drive.google.com/file/d/1pr5zvyUqP7UUralSMeV9V34A74V64xKn/view

Bookmark Directions:
1. Make a bookmark (The star on the right side of the url bar if you are using Chrome)
2. Click on more at the bottom left corner of the bookmark screen
3. Delete everything in the URL box
4. Type in "javascript:" without the quotes
5. Paste in the code
